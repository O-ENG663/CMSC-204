
public class ChatServerExecInterface {

}
