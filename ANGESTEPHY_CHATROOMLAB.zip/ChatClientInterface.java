
public class ChatClientInterface {

}
