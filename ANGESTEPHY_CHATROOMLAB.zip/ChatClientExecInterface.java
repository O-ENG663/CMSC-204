
public class ChatClientExecInterface {

}
