public class DictionaryEntry {
    private final String word;   // The word stored in this entry
    private int frequency;       // Number of times this word has been added

    /**
     * Constructor: creates a new DictionaryEntry for a word.
     * Initializes frequency to 1.
     */
    public DictionaryEntry(String word) {
        this.word = word.toLowerCase(); // Store word in lowercase
        this.frequency = 1;             // First occurrence
    }

    /**
     * Returns the word stored in this entry.
     */
    public String getWord() {
        return word;
    }

    /**
     * Returns the frequency (number of occurrences) of this word.
     */
    public int getFrequency() {
        return frequency;
    }

    /**
     * Increments the frequency when the word is added again.
     */
    public void addOccurrence() {
        frequency++;
    }

    /**
     * Decrements the frequency by 1, if frequency is greater than 0.
     */
    public void removeOccurrence() {
        if (frequency > 0) frequency--;
    }

    /**
     * Checks if this DictionaryEntry is equal to another object.
     * Two entries are equal if their words are the same.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;                         // Same object
        if (!(obj instanceof DictionaryEntry)) return false;  // Not a DictionaryEntry
        return word.equals(((DictionaryEntry) obj).word);     // Compare words
    }

    /**
     * Returns the hash code of this entry (based on the word).
     */
    @Override
    public int hashCode() {
        return word.hashCode();
    }
}
