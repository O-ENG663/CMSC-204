import java.util.*;

public class DictionaryLinkedList {

    /**
     * Inner Node class representing a single element in the linked list.
     */
    private class Node {
        DictionaryEntry data; // The dictionary entry stored in this node
        Node next;            // Reference to the next node in the list

        Node(DictionaryEntry entry) { 
            data = entry; 
            next = null; 
        }
    }

    private Node head; // Head of the linked list

    /**
     * Adds a DictionaryEntry to the linked list.
     * If the word already exists, increments its frequency.
     * New entries are added at the head of the list.
     */
    public void addWord(DictionaryEntry entry) {
        if (head == null) {
            head = new Node(entry); // First node in the list
            return;
        }
        Node current = head;
        while (current != null) {
            if (current.data.equals(entry)) {
                current.data.addOccurrence(); // Word exists, increment frequency
                return;
            }
            current = current.next;
        }
        // Word not found, add new node at the beginning
        Node n = new Node(entry);
        n.next = head;
        head = n;
    }

    /**
     * Removes a word from the linked list.
     * Returns true if removed successfully, false if word not found.
     */
    public boolean removeWord(String word) {
        Node current = head;
        Node prev = null;
        word = word.toLowerCase(); // Ensure comparison is case-insensitive
        while (current != null) {
            if (current.data.getWord().equals(word)) {
                if (prev == null) head = current.next; // Removing head node
                else prev.next = current.next;         // Bypass current node
                return true;
            }
            prev = current;
            current = current.next;
        }
        return false; // Word not found
    }

    /**
     * Finds and returns the DictionaryEntry for a given word.
     * Returns null if the word does not exist in the list.
     */
    public DictionaryEntry findWord(String word) {
        Node current = head;
        word = word.toLowerCase(); // Case-insensitive search
        while (current != null) {
            if (current.data.getWord().equals(word)) return current.data;
            current = current.next;
        }
        return null; // Word not found
    }

    /**
     * Returns a list of all DictionaryEntry objects in the linked list.
     */
    public List<DictionaryEntry> getEntries() {
        List<DictionaryEntry> list = new ArrayList<>();
        Node current = head;
        while (current != null) {
            list.add(current.data);
            current = current.next;
        }
        return list;
    }

    /**
     * Checks if the linked list is empty.
     */
    public boolean isEmpty() { 
        return head == null; 
    }
}
