import java.io.*;
import java.util.*;

public class DictionaryBuilder {

    // Hash table using separate chaining with linked lists
    private DictionaryLinkedList[] table; 
    private int tableSize;       // Size of the hash table
    private int totalWords;      // Counts all occurrences of words
    private int uniqueWords;     // Counts unique words in the dictionary

    /**
     * Constructor with estimated number of entries.
     * Allocates hash table size based on estimate and desired load factor (0.6).
     */
    public DictionaryBuilder(int estimatedEntries) {
        // Calculate next prime of the form 4k+3 to use as table size
        this.tableSize = next4kPlus3Prime((int) Math.ceil(estimatedEntries / 0.6));
        this.table = new DictionaryLinkedList[tableSize];
        // Initialize each bucket as an empty linked list
        for (int i = 0; i < tableSize; i++) table[i] = new DictionaryLinkedList();
        totalWords = 0;
        uniqueWords = 0;
    }

    /**
     * Constructor that builds dictionary from a file.
     * Reads words from file, cleans them, and adds to the hash table.
     */
    public DictionaryBuilder(String filename) throws FileNotFoundException {
        File file = new File(filename);
        // Estimate number of unique words based on file size (rough approximation)
        int estimatedUnique = (int) (file.length() / 100.0);
        this.tableSize = next4kPlus3Prime((int) Math.ceil(estimatedUnique / 0.6));
        this.table = new DictionaryLinkedList[tableSize];
        for (int i = 0; i < tableSize; i++) table[i] = new DictionaryLinkedList();
        totalWords = 0;
        uniqueWords = 0;

        // Read each word from the file and add to dictionary
        Scanner sc = new Scanner(file);
        while (sc.hasNext()) {
            String word = cleanWord(sc.next()); // Clean word: lowercase + remove non-letters
            if (!word.isEmpty()) addWord(word);
        }
        sc.close();
    }

    /**
     * Adds a word to the dictionary.
     * If the word already exists, increments its frequency.
     */
    public void addWord(String word) {
        word = cleanWord(word);
        if (word.isEmpty()) return; // Skip empty words

        // Compute hash index for the word
        int index = Math.abs(word.hashCode()) % tableSize;
        DictionaryEntry entry = table[index].findWord(word);
        if (entry == null) {
            // Word not found, create a new dictionary entry
            table[index].addWord(new DictionaryEntry(word));
            uniqueWords++;
            totalWords++;
        } else {
            // Word exists, increment its frequency
            entry.addOccurrence();
            totalWords++;
        }
    }

    /**
     * Returns the frequency (number of occurrences) of a given word.
     */
    public int getFrequency(String word) {
        word = cleanWord(word);
        int index = Math.abs(word.hashCode()) % tableSize;
        DictionaryEntry entry = table[index].findWord(word);
        return entry == null ? 0 : entry.getFrequency();
    }

    /**
     * Removes a word from the dictionary.
     * Throws exception if the word is not found.
     */
    public void removeWord(String word) throws DictionaryEntryNotFoundException {
        word = cleanWord(word);
        int index = Math.abs(word.hashCode()) % tableSize;
        boolean removed = table[index].removeWord(word);
        if (!removed) throw new DictionaryEntryNotFoundException(word);
        uniqueWords--;
        totalWords -= 1; // Only removes one occurrence from totalWords
    }

    /**
     * Returns a sorted list of all unique words in the dictionary.
     */
    public List<String> getAllWords() {
        List<String> allWords = new ArrayList<>();
        // Iterate over each bucket
        for (DictionaryLinkedList bucket : table) {
            // Add each word from the linked list
            for (DictionaryEntry e : bucket.getEntries()) {
                allWords.add(e.getWord());
            }
        }
        Collections.sort(allWords); // Sort alphabetically
        return allWords;
    }

    public int getTotalWords() { return totalWords; } // All occurrences
    public int getUniqueWords() { return uniqueWords; } // Unique words only
    public double getLoadFactor() { return (double) uniqueWords / tableSize; }

    /**
     * Cleans a word by:
     * - Converting to lowercase
     * - Removing all non-letter characters
     */
    private String cleanWord(String word) {
        if (word == null) return "";
        word = word.toLowerCase();
        StringBuilder sb = new StringBuilder();
        for (char c : word.toCharArray()) 
            if (Character.isLetter(c)) sb.append(c);
        return sb.toString();
    }

    // --- Prime number utilities ---

    /**
     * Returns the next prime number of the form 4k+3 that is >= n.
     */
    private int next4kPlus3Prime(int n) {
        while (true) {
            if (n % 4 != 3) n++;             // Ensure it satisfies 4k+3
            if (isPrime(n) && n % 4 == 3) return n;
            n++;
        }
    }

    /**
     * Checks if a number is prime.
     */
    private boolean isPrime(int n) {
        if (n <= 1) return false;
        if (n == 2 || n == 3) return true;
        if (n % 2 == 0 || n % 3 == 0) return false;
        for (int i = 5; i * i <= n; i += 6)
            if (n % i == 0 || n % (i + 2) == 0) return false;
        return true;
    }
}
