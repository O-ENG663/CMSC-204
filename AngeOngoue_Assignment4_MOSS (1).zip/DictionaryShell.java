import java.util.*;
import java.io.*;

public class DictionaryShell {

    private DictionaryBuilder dictionary; // The dictionary being managed
    private boolean running = true;       // Flag to control the CLI loop
    private Scanner sc;                   // Scanner to read user input

    /**
     * Main method: initializes the dictionary and starts the CLI.
     * If a filename is provided as a command-line argument, loads dictionary from file.
     * Otherwise, initializes with an estimated size of 100.
     */
    public static void main(String[] args) {
        DictionaryShell shell = new DictionaryShell();
        try {
            if (args.length > 0) 
                shell.dictionary = new DictionaryBuilder(args[0]); // Load from file
            else 
                shell.dictionary = new DictionaryBuilder(100);    // Default size
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + args[0]);
            return; // Exit if file cannot be found
        }
        shell.run(); // Start CLI
    }

    /**
     * Runs the interactive command-line interface for the dictionary.
     */
    private void run() {
        sc = new Scanner(System.in);
        System.out.println("Welcome to the Dictionary Builder CLI.");
        System.out.println("Available commands: add <word>, delete <word>, search <word>, list, stats, exit");

        while (running) {
            System.out.print("> ");
            String input = sc.nextLine().trim(); // Read user input and trim whitespace
            if (input.isEmpty()) continue;

            // Split command and argument
            int space = input.indexOf(' ');
            String cmd = (space == -1 ? input : input.substring(0, space)).toLowerCase();
            String arg = (space == -1 ? "" : input.substring(space + 1).trim());

            // Process the command
            switch (cmd) {
                case "add": performAddWord(arg); break;
                case "delete": performRemoveWord(arg); break;
                case "remove": performRemoveWord(arg); break; // Alias for delete
                case "list": performList(); break;
                case "search": performSearch(arg); break;
                case "stats": performStats(); break;
                case "exit": case "quit": running = false; break;
                default: System.out.println("Unknown command.");
            }
        }
        System.out.println("Quitting...");
    }

    /**
     * Adds a word to the dictionary.
     */
    private void performAddWord(String w) {
        if (w.isEmpty()) { 
            System.out.println("Usage: add <word>"); 
            return; 
        }
        dictionary.addWord(w);
        System.out.println("\"" + w + "\" added.");
    }

    /**
     * Removes a word from the dictionary.
     * Prints a message if the word is not found.
     */
    private void performRemoveWord(String w) {
        if (w.isEmpty()) { 
            System.out.println("Usage: delete <word>"); 
            return; 
        }
        try {
            dictionary.removeWord(w);
            System.out.println("\"" + w + "\" deleted.");
        } catch (Exception e) {
            System.out.println("\"" + w + "\" not found.");
        }
    }

    /**
     * Prints all unique words in the dictionary in alphabetical order.
     */
    private void performList() {
        for (String w : dictionary.getAllWords()) 
            System.out.println(w);
    }

    /**
     * Searches for a word in the dictionary and prints its frequency.
     */
    private void performSearch(String w) {
        if (w.isEmpty()) { 
            System.out.println("Usage: search <word>"); 
            return; 
        }
        int freq = dictionary.getFrequency(w);
        if (freq == 0) 
            System.out.println("\"" + w + "\" not found.");
        else 
            System.out.println(freq + " instance(s) of \"" + w + "\" found.");
    }

    /**
     * Prints statistics about the dictionary.
     */
    private void performStats() {
        System.out.printf("Total words: %d%n", dictionary.getTotalWords());
        System.out.printf("Total unique words: %d%n", dictionary.getUniqueWords());
        System.out.printf("Estimated load factor: %.2f%n", dictionary.getLoadFactor());
    }
}
