/**
 * Custom exception thrown when a word is not found in the dictionary.
 */
public class DictionaryEntryNotFoundException extends Exception {
    private static final long serialVersionUID = 1L; // Unique ID for serialization

    /**
     * Default constructor.
     */
    public DictionaryEntryNotFoundException() {
        super(); // Call parent Exception constructor
    }

    /**
     * Constructor that accepts a custom error message.
     * @param message The message to include with the exception
     */
    public DictionaryEntryNotFoundException(String message) {
        super(message); // Pass message to parent Exception class
    }
}
