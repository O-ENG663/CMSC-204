package cmsc204;

import java.io.Serializable;

public class UserAccount implements Serializable {

    private static final long serialVersionUID = 1L; // fixes serialization warning

    private String username;
    private String encryptedPassword;
    private int failureCount;
    private boolean locked;

    public UserAccount(String username, String encryptedPassword) {
        this.username = username;
        this.encryptedPassword = encryptedPassword;
        this.failureCount = 0;
        this.locked = false;
    }

    public String getUsername() {
        return username;
    }

    public String getEncryptedPassword() {
        return encryptedPassword;
    }

    public void incrementFailure() {
        failureCount++;
        if (failureCount >= 3) {
            locked = true;
        }
    }

    public void resetFailure() {
        failureCount = 0;
    }

    public boolean isLocked() {
        return locked;
    }

    public boolean checkPassword(String password) 
            throws AccountLockedException, PasswordIncorrectException {

        if (locked) {
            throw new AccountLockedException(username + " account is locked.");
        }

        String encryptedInput = Utilities.encryptPassword(password);
        if (!encryptedInput.equals(encryptedPassword)) {
            incrementFailure();
            throw new PasswordIncorrectException("Incorrect Password");
        }

        resetFailure();
        return true;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof UserAccount)) return false;
        UserAccount other = (UserAccount) obj;
        return username.equals(other.username);
    }

    @Override
    public String toString() {
        return username;
    }
}