package cmsc204;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        UserAccessManager manager = new UserAccessManager();

        try (Scanner scanner = new Scanner(System.in)) { // auto-close to avoid resource leak
            System.out.println("User access manager ready.");

            while (true) {
                System.out.print("User Access Manager> ");
                String input = scanner.nextLine().trim();
                if (input.isEmpty()) continue;

                String[] parts = input.split("\\s+");
                String command = parts[0];

                try {
                    switch (command) {
                        case "exit":
                            return;

                        case "load":
                            if (parts.length < 2) throw new InvalidCommandException("Filename required");
                            manager.loadAccounts(parts[1]);
                            break;

                        case "add":
                            if (parts.length < 2) throw new InvalidCommandException("Username required");
                            System.out.print("Password: ");
                            String passwordAdd = scanner.nextLine();
                            manager.addUser(parts[1], Utilities.encryptPassword(passwordAdd));
                            break;

                        case "remove":
                            if (parts.length < 2) throw new InvalidCommandException("Username required");
                            manager.removeUser(parts[1]);
                            break;

                        case "verify":
                            if (parts.length < 2) throw new InvalidCommandException("Username required");
                            System.out.print("Password: ");
                            String passwordVerify = scanner.nextLine();
                            try {
                                if (manager.verifyAccess(parts[1], Utilities.encryptPassword(passwordVerify))) {
                                    System.out.println("Access granted.");
                                }
                            } catch (PasswordIncorrectException e) {
                                System.out.println(e.getMessage());
                            }
                            break;

                        default:
                            throw new InvalidCommandException("Invalid command: " + command);
                    }
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }

        } catch (Exception e) {
            System.out.println("Fatal error: " + e.getMessage());
        }
    }
}