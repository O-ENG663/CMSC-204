package cmsc204;

import java.io.File;
import java.io.FileNotFoundException;
import java.security.MessageDigest;
import java.util.Scanner;

public class Utilities {

    // SHA-256 password encryption
    public static String encryptPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes("UTF-8"));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) {
                hex.append(String.format("%02x", b));
            }
            return hex.toString();
        } catch (Exception e) {
            throw new RuntimeException("Error encrypting password");
        }
    }

    // Read accounts from file and add to manager
    public static void readAccountFile(String filename, UserAccessManager manager) throws FileNotFoundException {
        File file = new File(filename);
        try (Scanner scanner = new Scanner(file)) { // auto-close scanner
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split("\\s+");
                if (parts.length != 2) continue;
                try {
                    manager.addUser(parts[0], parts[1]);
                } catch (DuplicateUserException | InvalidCommandException e) {
                    System.out.println("Warning: " + e.getMessage());
                }
            }
        }
    }
}
