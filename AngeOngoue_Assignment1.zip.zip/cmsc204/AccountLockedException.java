package cmsc204;

public class AccountLockedException extends Exception {
    private static final long serialVersionUID = 1L; // fixes warning

    public AccountLockedException(String message) {
        super(message);
    }
}