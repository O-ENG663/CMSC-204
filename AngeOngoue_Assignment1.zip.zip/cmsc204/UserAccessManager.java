package cmsc204;

import java.util.ArrayList;
import java.util.List;
import java.io.FileNotFoundException;

public class UserAccessManager {

    private List<UserAccount> accounts;

    public UserAccessManager() {
        accounts = new ArrayList<>();
    }

    public void loadAccounts(String filename) throws FileNotFoundException {
        Utilities.readAccountFile(filename, this);
    }

    public void addUser(String username, String encryptedPassword) 
            throws DuplicateUserException, InvalidCommandException {

        if (username == null || username.isEmpty() || encryptedPassword == null || encryptedPassword.isEmpty()) {
            throw new InvalidCommandException("Username or password cannot be empty");
        }

        UserAccount newUser = new UserAccount(username, encryptedPassword);
        if (accounts.contains(newUser)) {
            throw new DuplicateUserException("User '" + username + "' account already exists.");
        }

        accounts.add(newUser);
        System.out.println("User '" + username + "' added successfully.");
    }

    public void removeUser(String username) throws UserNotFoundException, InvalidCommandException {
        if (username == null || username.isEmpty()) {
            throw new InvalidCommandException("Username cannot be empty");
        }

        UserAccount temp = new UserAccount(username, ""); // password irrelevant for equals
        if (!accounts.remove(temp)) {
            throw new UserNotFoundException("User '" + username + "' not found.");
        }

        System.out.println("User '" + username + "' removed successfully.");
    }

    public boolean verifyAccess(String username, String encryptedPassword) 
            throws UserNotFoundException, AccountLockedException, PasswordIncorrectException, InvalidCommandException {

        if (username == null || username.isEmpty()) {
            throw new InvalidCommandException("Username cannot be empty");
        }

        UserAccount user = accounts.stream()
                                   .filter(a -> a.getUsername().equals(username))
                                   .findFirst()
                                   .orElseThrow(() -> new UserNotFoundException("User '" + username + "' not found."));

        return user.checkPassword(encryptedPassword);
    }

    public List<UserAccount> getAccounts() {
        return accounts;
    }
}
