package ProductSalesTracker;

public class ProductSalesTracker {

    private double[] salesRecords;  
    private int numberOfSales;     

    public ProductSalesTracker(int capacity) {
        salesRecords = new double[capacity];
        numberOfSales = 0;
    }

    
    public boolean addNewSale(double saleValue) {
        if (numberOfSales < salesRecords.length) {
            salesRecords[numberOfSales] = saleValue;
            numberOfSales++;
            return true;
        }
        return false;
    }

    public double getTotalSales() {
        double sum = 0;
        for (int i = 0; i < numberOfSales; i++) {
            sum += salesRecords[i];
        }
        return sum;
    }

   
    public double getSmallestSale() {
        if (numberOfSales == 0) return 0;
        double min = salesRecords[0];
        for (int i = 1; i < numberOfSales; i++) {
            if (salesRecords[i] < min) {
                min = salesRecords[i];
            }
        }
        return min;
    }

    
    public double getAdjustedTotal() {
        if (numberOfSales == 0) return 0.0;
        if (numberOfSales == 1) return salesRecords[0];
        return getTotalSales() - getSmallestSale();
    }

    public int getSalesCount() {
        return numberOfSales;
    }

    @Override
    public String toString() {
        if (numberOfSales == 0) return "";
        StringBuilder result = new StringBuilder();
        result.append(salesRecords[0]);
        for (int i = 1; i < numberOfSales; i++) {
            result.append(" ").append(salesRecords[i]);
        }
        return result.toString();
    }
}
