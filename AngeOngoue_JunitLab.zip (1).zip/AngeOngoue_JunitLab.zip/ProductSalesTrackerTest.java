package ProductSalesTracker;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;

public class ProductSalesTrackerTest {

    private ProductSalesTracker salesTracker1;
    private ProductSalesTracker salesTracker2;

    @Before
    public void setUp() {
        // Create two trackers with a capacity of 5
        salesTracker1 = new ProductSalesTracker(5);
        salesTracker2 = new ProductSalesTracker(5);

        // Add initial sales to tracker 1
        salesTracker1.addNewSale(115.0);
        salesTracker1.addNewSale(225.0);

        // Add initial sales to tracker 2
        salesTracker2.addNewSale(65.0);
        salesTracker2.addNewSale(85.0);
    }

    @After
    public void tearDown() {
        // Clear trackers after each test
        salesTracker1 = null;
        salesTracker2 = null;
    }

    @Test
    public void testAddingSales() {
        // Add sales within capacity
        assertTrue(salesTracker1.addNewSale(335.0));
        assertTrue(salesTracker1.addNewSale(445.0));
        assertTrue(salesTracker1.addNewSale(555.0));

        // Adding beyond capacity should fail
        assertFalse(salesTracker1.addNewSale(999.0));
    }

    @Test
    public void testTotalSales() {
        // Check total sales calculation
        assertEquals(340.0, salesTracker1.getTotalSales(), 0.001);
        assertEquals(150.0, salesTracker2.getTotalSales(), 0.001);
    }

    @Test
    public void testLowestSale() {
        // Check the smallest sale recorded
        assertEquals(115.0, salesTracker1.getSmallestSale(), 0.001);
        assertEquals(65.0, salesTracker2.getSmallestSale(), 0.001);
    }

    @Test
    public void testFinalSalesExcludingLowest() {
        // Check adjusted total after removing lowest sale
        assertEquals(225.0, salesTracker1.getAdjustedTotal(), 0.001);
        assertEquals(85.0, salesTracker2.getAdjustedTotal(), 0.001);
    }

    @Test
    public void testSalesCount() {
        // Verify the number of sales recorded
        assertEquals(2, salesTracker1.getSalesCount());
        assertEquals(2, salesTracker2.getSalesCount());
    }

    @Test
    public void testToStringOutput() {
        // Check string representation of sales
        assertEquals("115.0 225.0", salesTracker1.toString());
        assertEquals("65.0 85.0", salesTracker2.toString());
    }
}
