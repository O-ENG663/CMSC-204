import java.util.ArrayList;

/**
 * MorseCodeTree implements a linked binary tree for Morse code conversion.
 */
public class MorseCodeTree implements LinkedConverterTreeInterface<String> {

    private TreeNode<String> root;

    // Constructor
    public MorseCodeTree() {
        buildTree();
    }

    @Override
    public TreeNode<String> getRoot() {
        return root;
    }

    @Override
    public void setRoot(TreeNode<String> newRoot) {
        this.root = newRoot;
    }

    @Override
    public void insert(String code, String letter) {
        addNode(root, code, letter);
    }

    @Override
    public void addNode(TreeNode<String> node, String code, String letter) {
        if (code.length() == 0) {
            node.setData(letter);
            return;
        }

        char direction = code.charAt(0);
        if (direction == '.') {
            if (node.getLeft() == null) node.setLeft(new TreeNode<String>(""));
            addNode(node.getLeft(), code.substring(1), letter);
        } else if (direction == '-') {
            if (node.getRight() == null) node.setRight(new TreeNode<String>(""));
            addNode(node.getRight(), code.substring(1), letter);
        } else {
            throw new IllegalArgumentException("Invalid Morse code");
        }
    }

    @Override
    public String fetch(String code) {
        return fetchNode(root, code);
    }

    @Override
    public String fetchNode(TreeNode<String> node, String code) {
        if (node == null) return "";
        if (code.length() == 0) return node.getData();

        char direction = code.charAt(0);
        if (direction == '.') return fetchNode(node.getLeft(), code.substring(1));
        else if (direction == '-') return fetchNode(node.getRight(), code.substring(1));
        else throw new IllegalArgumentException("Invalid Morse code");
    }

    @Override
    public LinkedConverterTreeInterface<String> delete(String data) {
        throw new UnsupportedOperationException("Delete not supported");
    }

    @Override
    public LinkedConverterTreeInterface<String> update() {
        throw new UnsupportedOperationException("Update not supported");
    }

    @Override
    public void buildTree() {
        root = new TreeNode<String>("");

        // Level 1
        insert(".", "e");
        insert("-", "t");

        // Level 2
        insert("..", "i");
        insert(".-", "a");
        insert("-.", "n");
        insert("--", "m");

        // Level 3
        insert("...", "s");
        insert("..-", "u");
        insert(".-.", "r");
        insert(".--", "w");
        insert("-..", "d");
        insert("-.-", "k");
        insert("--.", "g");
        insert("---", "o");

        // Level 4
        insert("....", "h");
        insert("...-", "v");
        insert("..-.", "f");
        insert(".-..", "l");
        insert(".--.", "p");
        insert(".---", "j");
        insert("-...", "b");
        insert("-..-", "x");
        insert("-.-.", "c");
        insert("-.--", "y");
        insert("--..", "z");
        insert("--.-", "q");
    }

    @Override
    public ArrayList<String> toArrayList() {
        ArrayList<String> list = new ArrayList<>();
        LNRoutputTraversal(root, list);
        return list;
    }

    @Override
    public void LNRoutputTraversal(TreeNode<String> node, ArrayList<String> list) {
        if (node == null) return;

        LNRoutputTraversal(node.getLeft(), list);
        list.add(node.getData());
        LNRoutputTraversal(node.getRight(), list);
    }
}
