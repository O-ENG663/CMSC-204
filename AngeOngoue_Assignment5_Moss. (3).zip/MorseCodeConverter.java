import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Utility class to convert Morse code to English.
 */
public class MorseCodeConverter {

    private static MorseCodeTree tree = new MorseCodeTree();

    /**
     * Prints tree in LNR order as a string.
     */
    public static String printTree() {
        ArrayList<String> list = tree.toArrayList();
        StringBuilder sb = new StringBuilder();
        for (String s : list) sb.append(s).append(" ");
        return sb.toString().trim();
    }

    /**
     * Convert Morse code string to English.
     * Letters separated by space, words by "/".
     */
    public static String convertToEnglish(String code) {
        StringBuilder english = new StringBuilder();
        String[] words = code.trim().split("/");

        for (int i = 0; i < words.length; i++) {
            String[] letters = words[i].trim().split("\\s+");
            for (String l : letters) {
                if (!l.isEmpty()) english.append(tree.fetch(l));
            }
            if (i < words.length - 1) english.append(" ");
        }

        return english.toString().toLowerCase();
    }

    /**
     * Convert Morse code from a file to English string.
     */
    public static String convertToEnglish(File file) throws FileNotFoundException {
        StringBuilder morse = new StringBuilder();
        try (Scanner sc = new Scanner(file)) {
            boolean firstLine = true;
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (line.isEmpty()) continue;
                if (!firstLine) morse.append(" / "); // separate words/lines
                morse.append(line);
                firstLine = false;
            }
        }
        return convertToEnglish(morse.toString());
    }
}
