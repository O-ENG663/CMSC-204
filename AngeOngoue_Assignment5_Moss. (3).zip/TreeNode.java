/**
 * Generic TreeNode class for MorseCodeTree.
 * @param <T> type of data stored in the node
 */
public class TreeNode<T> {
    private T data;
    private TreeNode<T> left;
    private TreeNode<T> right;

    // Constructor for leaf node
    public TreeNode(T data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }

    // Constructor for node with children
    public TreeNode(T data, TreeNode<T> left, TreeNode<T> right) {
        this.data = data;
        this.left = left;
        this.right = right;
    }

    // Getters and setters
    public T getData() { return data; }
    public void setData(T data) { this.data = data; }

    public TreeNode<T> getLeft() { return left; }
    public void setLeft(TreeNode<T> left) { this.left = left; }

    public TreeNode<T> getRight() { return right; }
    public void setRight(TreeNode<T> right) { this.right = right; }
}
