import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class CarQueue {
    private Queue<Integer> queue = new LinkedList<>();
    private Random rand = new Random();

    public CarQueue() {
        // preload 6 random directions
        for (int i = 0; i < 6; i++) {
            queue.add(rand.nextInt(4)); // 0–3
        }
    }

    /** Starts a thread that continuously adds random directions */
    public void addToQueue() {
        Runnable r = new Runnable() {
            public void run() {
                try {
                    while (true) {
                        queue.add(rand.nextInt(4)); 
                        Thread.sleep(500); // half-second pause
                    }
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        };

        Thread t = new Thread(r);
        t.start();
    }

    /** Removes and returns an Integer direction */
    public Integer deleteQueue() {
        return queue.poll();   // returns null if empty
    }
}
