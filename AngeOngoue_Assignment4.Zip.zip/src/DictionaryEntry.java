public class DictionaryEntry {
    private String word;
    private int frequency;

    public DictionaryEntry(String word) {
        this.word = word.toLowerCase();
        this.frequency = 1;
    }

    public void incrementFrequency() {
        frequency++;
    }

    public int getFrequency() {
        return frequency;
    }

    public String getWord() {
        return word;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof DictionaryEntry)) return false;
        DictionaryEntry other = (DictionaryEntry) obj;
        return this.word.equals(other.word);
    }

    @Override
    public int hashCode() {
        return word.hashCode();
    }
}
