import java.io.FileNotFoundException;
import java.util.Scanner;

public class DictionaryShell {
    public static void main(String[] args) {
        DictionaryBuilder dict = null;
        try {
            if (args.length > 0) dict = new DictionaryBuilder(args[0]);
            else dict = new DictionaryBuilder(100); // default size
        } catch (FileNotFoundException e) {
            System.out.println("File not found, starting with empty dictionary.");
            dict = new DictionaryBuilder(100);
        }

        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Dictionary Builder CLI.");
        System.out.println("Available commands: add <word>, delete <word>, search <word>, list, stats, exit");

        while (true) {
            System.out.print("> ");
            String line = scanner.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\s+", 2);
            String command = parts[0].toLowerCase();
            String argument = parts.length > 1 ? parts[1] : "";

            switch (command) {
                case "search":
                    int freq = dict.getFrequency(argument);
                    if (freq > 0) System.out.println(freq + " instance(s) of \"" + argument + "\" found.");
                    else System.out.println("\"" + argument + "\" not found.");
                    break;
                case "add":
                    dict.addWord(argument);
                    System.out.println("\"" + argument + "\" added.");
                    break;
                case "delete":
                    if (dict.removeWord(argument)) System.out.println("\"" + argument + "\" deleted.");
                    else System.out.println("\"" + argument + "\" not found.");
                    break;
                case "list":
                    for (String w : dict.getAllWords()) System.out.println(w);
                    break;
                case "stats":
                    System.out.println("Total words: " + dict.getTotalWords());
                    System.out.println("Total unique words: " + dict.getUniqueWords());
                    System.out.printf("Estimated load factor: %.2f%n", dict.getLoadFactor());
                    break;
                case "exit":
                    System.out.println("Quitting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Unknown command.");
            }
        }
    }
}
