import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class DictionaryBuilder {
    private LinkedList<DictionaryEntry>[] table;
    private int numElements;
    private final double LOAD_FACTOR = 0.6;

    // Constructor using estimated entries
    public DictionaryBuilder(int estimatedEntries) {
        int tableSize = nextPrime((int) (estimatedEntries / LOAD_FACTOR));
        table = new LinkedList[tableSize];
        for (int i = 0; i < tableSize; i++) table[i] = new LinkedList<>();
        numElements = 0;
    }

    // Constructor using a file
    public DictionaryBuilder(String filename) throws FileNotFoundException {
        File file = new File(filename);
        int estimated = (int) (file.length() / 100.0); // heuristic: 1 unique word per 100 bytes
        int tableSize = nextPrime((int) (estimated / LOAD_FACTOR));

        table = new LinkedList[tableSize];
        for (int i = 0; i < tableSize; i++) table[i] = new LinkedList<>();
        numElements = 0;

        Scanner sc = new Scanner(file);
        while (sc.hasNext()) {
            String word = cleanWord(sc.next());
            if (!word.isEmpty()) addWord(word);
        }
        sc.close();
    }

    // Clean word: lowercase and remove non-letter characters
    private String cleanWord(String word) {
        return word.toLowerCase().replaceAll("[^a-z]", "");
    }

    // Hash function
    private int hash(String word) {
        return Math.abs(word.hashCode()) % table.length;
    }

    // Add a word to the dictionary
    public void addWord(String word) {
        word = cleanWord(word);
        int index = hash(word);
        Node<DictionaryEntry> node = table[index].find(new DictionaryEntry(word));
        if (node != null) {
            node.data.incrementFrequency();
        } else {
            table[index].add(new DictionaryEntry(word));
            numElements++;
        }
    }

    // Get frequency of a word
    public int getFrequency(String word) {
        word = cleanWord(word);
        int index = hash(word);
        Node<DictionaryEntry> node = table[index].find(new DictionaryEntry(word));
        return (node != null) ? node.data.getFrequency() : 0;
    }

    // Remove a word; returns true if removed, false if not found
    public boolean removeWord(String word) {
        word = cleanWord(word);
        int index = hash(word);
        Node<DictionaryEntry> node = table[index].find(new DictionaryEntry(word));
        if (node != null) {
            table[index].remove(node.data);
            numElements--;
            return true;
        }
        return false;
    }

    // Return all words sorted alphabetically
    public ArrayList<String> getAllWords() {
        ArrayList<String> words = new ArrayList<>();
        for (LinkedList<DictionaryEntry> bucket : table) {
            for (DictionaryEntry entry : bucket.toArrayList()) {
                words.add(entry.getWord());
            }
        }
        Collections.sort(words);
        return words;
    }

    // Total words including duplicates
    public int getTotalWords() {
        int total = 0;
        for (LinkedList<DictionaryEntry> bucket : table) {
            for (DictionaryEntry entry : bucket.toArrayList()) {
                total += entry.getFrequency();
            }
        }
        return total;
    }

    // Total unique words
    public int getUniqueWords() {
        return numElements;
    }

    // Estimated load factor
    public double getLoadFactor() {
        return (double) numElements / table.length;
    }

    // Find next prime of the form 4k+3 >= n
    private int nextPrime(int n) {
        while (!isPrime(n) || n % 4 != 3) n++;
        return n;
    }

    // Prime check using 6k±1 optimization
    private boolean isPrime(int n) {
        if (n <= 1) return false;
        if (n <= 3) return true;
        if (n % 2 == 0 || n % 3 == 0) return false;
        for (int i = 5; i * i <= n; i += 6)
            if (n % i == 0 || n % (i + 2) == 0) return false;
        return true;
    }
}
